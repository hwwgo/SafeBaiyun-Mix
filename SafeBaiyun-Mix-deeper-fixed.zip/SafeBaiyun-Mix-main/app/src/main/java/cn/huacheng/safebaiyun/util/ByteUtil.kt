package cn.huacheng.safebaiyun.util

/**
 *
 *@description:
 *@author: guangzhou
 *@create: 2024-03-04
 */
object ByteUtil {

    private val hexChars = "0123456789abcdef".toCharArray()

    fun byteToHex(b: Byte): String {
        return "${hexChars[(b.toInt() shr 4) and 0x0F]}${hexChars[b.toInt() and 0x0F]}"
    }

    fun bytesToHex(bytes: ByteArray): String {
        val result = StringBuilder(bytes.size * 2)
        bytes.forEach {
            val octet = it.toInt()
            result.append(hexChars[(octet shr 4) and 0x0F])
            result.append(hexChars[octet and 0x0F])
        }
        return result.toString()
    }

    fun hexToBytes(hexString: String): ByteArray {
        val value = hexString.trim()
        if (value.isEmpty()) return byteArrayOf()
        require(value.length % 2 == 0 && value.matches(Regex("^[0-9A-Fa-f]+$"))) {
            "Invalid hexadecimal string"
        }
        return ByteArray(value.length / 2) { i ->
            value.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

}

