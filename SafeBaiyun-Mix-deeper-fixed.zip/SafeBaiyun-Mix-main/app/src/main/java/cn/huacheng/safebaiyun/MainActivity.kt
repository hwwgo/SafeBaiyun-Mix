package cn.huacheng.safebaiyun

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.slideIn
import androidx.compose.animation.slideOut
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.IntOffset
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import cn.huacheng.safebaiyun.compose.HelpView
import cn.huacheng.safebaiyun.compose.MainView
import cn.huacheng.safebaiyun.compose.ManageDoorsView
import cn.huacheng.safebaiyun.compose.QRExportView
import cn.huacheng.safebaiyun.compose.QRImportView
import cn.huacheng.safebaiyun.compose.SettingsView
import cn.huacheng.safebaiyun.theme.SafeBaiyunTheme
import cn.huacheng.safebaiyun.unlock.DataRepo
import cn.huacheng.safebaiyun.unlock.UnlockRepo
import cn.huacheng.safebaiyun.util.ConfigManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ConfigManager.init(this)
        UnlockRepo.init(lifecycleScope)

        setContent {
            SafeBaiyunTheme {
                val navController = rememberNavController()
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = "main",
                    ) {
                        composable("main", enterTransition = {
                            slideIn { IntOffset(-it.width, 0) }
                        }, exitTransition = {
                            slideOut { IntOffset(-it.width, 0) }
                        }) {
                            MainView(navController)
                        }

                        composable("manage_doors", enterTransition = {
                            slideIn { IntOffset(it.width, 0) }
                        }, exitTransition = {
                            slideOut { IntOffset(it.width, 0) }
                        }) {
                            ManageDoorsView(
                                navController = navController,
                                onSaved = { /* 可在此刷新数据 */ }
                            )
                        }

                        composable("helper", enterTransition = {
                            slideIn { IntOffset(it.width, 0) }
                        }, exitTransition = {
                            slideOut { IntOffset(it.width, 0) }
                        }) {
                            HelpView(navController)
                        }

                        // 修复：统一从右边进入
                        composable("qr_export", enterTransition = {
                            slideIn { IntOffset(it.width, 0) }
                        }, exitTransition = {
                            slideOut { IntOffset(it.width, 0) }
                        }) {
                            QRExportView(navController)
                        }

                        // 修复：统一从右边进入
                        composable("qr_import", enterTransition = {
                            slideIn { IntOffset(it.width, 0) }
                        }, exitTransition = {
                            slideOut { IntOffset(it.width, 0) }
                        }) {
                            QRImportView(navController)
                        }

                        composable("settings", enterTransition = {
                            slideIn { IntOffset(it.width, 0) }
                        }, exitTransition = {
                            slideOut { IntOffset(it.width, 0) }
                        }) {
                            SettingsView(navController)
                        }
                    }
                }
            }
        }
    }
}
