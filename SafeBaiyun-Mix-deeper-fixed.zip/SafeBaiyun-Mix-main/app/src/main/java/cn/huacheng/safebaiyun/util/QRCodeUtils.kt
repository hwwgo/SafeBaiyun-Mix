package cn.huacheng.safebaiyun.util

import android.content.Context
import android.provider.MediaStore
import android.graphics.Bitmap
import android.graphics.Color
import android.util.Base64
import cn.huacheng.safebaiyun.unlock.DoorDevice
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

object QRCodeUtils {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true  // 确保 isSelected 也被序列化
    }

    private const val PREFIX = "SBY|"

    fun encodeDoorsToQR(doors: List<DoorDevice>): String {
        return try {
            val jsonStr = json.encodeToString(doors)
            val encoded = Base64.encodeToString(jsonStr.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            "$PREFIX$encoded"
        } catch (e: Exception) {
            e.printStackTrace()
            throw IllegalStateException("序列化门禁数据失败: ${e.message}", e)
        }
    }

    fun decodeQRTodoors(data: String): List<DoorDevice>? {
        if (!data.startsWith(PREFIX)) {
            return null
        }
        return try {
            val base64Data = data.removePrefix(PREFIX)
            if (base64Data.length > 100_000) return null
            val jsonString = String(Base64.decode(base64Data, Base64.DEFAULT), Charsets.UTF_8)
            val doors = json.decodeFromString<List<DoorDevice>>(jsonString)
            if (doors.size > 50) return null

            val ids = HashSet<String>()
            val normalized = doors.mapNotNull { door ->
                val mac = door.mac.trim()
                val key = door.key.trim()
                if (!android.bluetooth.BluetoothAdapter.checkBluetoothAddress(mac) ||
                    !key.matches(Regex("^[0-9A-Fa-f]{16}$"))
                ) return@mapNotNull null
                val id = if (door.id.isNotBlank() && ids.add(door.id)) door.id
                else java.util.UUID.randomUUID().toString().also { ids.add(it) }
                door.copy(
                    id = id,
                    name = door.name.trim().take(64).ifEmpty { "门禁" },
                    mac = mac.uppercase(),
                    key = key.uppercase()
                )
            }
            if (normalized.size != doors.size) return null
            normalized
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun generateQRCode(data: String, size: Int = 512): Bitmap {
        val hints = mapOf<EncodeHintType, Any>(
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.MARGIN to 1,
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.H
        )

        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(data, BarcodeFormat.QR_CODE, size, size, hints)

        val width = bitMatrix.width
        val height = bitMatrix.height
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)

        for (x in 0 until width) {
            for (y in 0 until height) {
                bitmap.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
            }
        }

        return bitmap
    }

    fun saveQRCodeToGallery(context: Context, bitmap: Bitmap): Boolean {
        var uri: android.net.Uri? = null
        return try {
            val filename = "door_config_${System.currentTimeMillis()}.png"
            val values = android.content.ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SafeBaiyun")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            uri = context.contentResolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            ) ?: return false

            val success = context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            } == true

            if (!success) {
                context.contentResolver.delete(uri, null, null)
                return false
            }

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val done = android.content.ContentValues().apply {
                    put(MediaStore.Images.Media.IS_PENDING, 0)
                }
                context.contentResolver.update(uri, done, null, null)
            }
            true
        } catch (e: Exception) {
            uri?.let { context.contentResolver.delete(it, null, null) }
            false
        }
    }
}
