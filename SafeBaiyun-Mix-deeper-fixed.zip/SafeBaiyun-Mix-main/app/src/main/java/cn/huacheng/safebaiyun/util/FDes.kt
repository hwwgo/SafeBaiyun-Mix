package cn.huacheng.safebaiyun.util

import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 *
 *@description:
 *@author: guangzhou
 *@create: 2024-03-04
 */

object FDes {

    fun encryptData(data: ByteArray, key: ByteArray): ByteArray {
        require(key.size == 8) { "DES key must be 8 bytes" }
        require(data.isNotEmpty() && data.size % 8 == 0) {
            "DES input length must be a positive multiple of 8"
        }
        val cipher = Cipher.getInstance("DES/ECB/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "DES"))
        return cipher.doFinal(data)
    }

}
